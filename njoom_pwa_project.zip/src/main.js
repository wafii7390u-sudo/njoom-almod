import { createClient } from '@supabase/supabase-js';
import './style.css';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;
const configured = Boolean(SUPABASE_URL && SUPABASE_KEY && !SUPABASE_URL.includes('YOUR-PROJECT') && !SUPABASE_KEY.includes('YOUR_SUPABASE'));
const supabase = configured ? createClient(SUPABASE_URL, SUPABASE_KEY) : null;
const app = document.querySelector('#app');

const state = { session: null, profile: null, view: 'home', loading: false, message: '' };
const sectionOptions = '<option value="الروضة">الروضة</option><option value="التقوى">التقوى</option>';

function escapeHtml(value='') {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function note(text, bad=false) {
  state.message = text;
  const el = document.querySelector('#notice');
  if (el) { el.textContent = text; el.className = `notice ${bad ? 'bad' : 'good'}`; el.hidden = false; }
}
function shell(content) {
  app.innerHTML = `<header class="top"><div class="brand"><div class="mark">✦</div><div><strong>مركز نجوم المضيئة</strong><small>منصة التقوى والروضة</small></div></div><div class="top-actions">${state.session ? `<span class="who">${escapeHtml(state.profile?.full_name || state.session.user.email)}</span><button class="btn ghost" id="logout">تسجيل الخروج</button>` : ''}</div></header><main><div id="notice" class="notice" hidden></div>${content}</main><footer>مركز نجوم المضيئة · منصة تعليمية</footer>`;
  document.querySelector('#logout')?.addEventListener('click', async () => { await supabase.auth.signOut(); state.session=null; state.profile=null; render(); });
}
function renderSetup() {
  shell(`<section class="hero"><span class="eyebrow">نسخة مشروع جاهزة للإعداد</span><h1>منصة تعليمية تجمع <span>الأسرة والمركز</span></h1><p>سجّل الطفل، تابع حالة الطلب، واطّلع على الإعلانات والدروس بعد تسجيل الدخول.</p><div class="chips"><span>قسم التقوى</span><span>قسم الروضة</span><span>حسابات منفصلة</span></div></section><section class="panel"><h2>يلزم ربط قاعدة البيانات أولًا</h2><p>المشروع يحتوي على واجهة التطبيق وملف إعداد قاعدة البيانات وسياسات الصلاحيات. قبل استخدامه، أنشئ مشروع Supabase وأضف مفاتيح الاتصال في ملف <code>.env</code>.</p><ol><li>انسخ <code>.env.example</code> إلى <code>.env</code>.</li><li>ضع رابط مشروع Supabase والمفتاح العام فقط.</li><li>نفّذ <code>supabase/schema.sql</code> في SQL Editor.</li><li>اتبع تعليمات README لإعداد حساب الإدارة والنشر.</li></ol><p class="warn">لا تدخل بيانات أطفال حقيقية قبل إكمال إعداد الأمان ونشر الخدمة والتحقق منها.</p></section>`);
}
function renderAuth() {
  shell(`<section class="auth-wrap"><div class="hero compact"><span class="eyebrow">أهلًا بكم</span><h1>دخول منصة <span>نجوم المضيئة</span></h1><p>استخدم بريدك الإلكتروني للدخول، أو أنشئ حساب الأم لتسجيل الطفل.</p></div><div class="auth-grid"><section class="panel"><h2>تسجيل الدخول</h2><form id="login-form"><label>البريد الإلكتروني<input name="email" type="email" autocomplete="email" required placeholder="name@example.com"></label><label>كلمة المرور<input name="password" type="password" autocomplete="current-password" required minlength="8"></label><button class="btn primary full">دخول</button></form><button class="text-btn" id="forgot">نسيت كلمة المرور؟</button></section><section class="panel"><h2>حساب أم جديد</h2><p class="muted">أنشئي حسابًا ثم سجّلي بيانات طفلك. يبقى الطلب مؤقتًا حتى موافقة الإدارة.</p><form id="signup-form"><label>اسم الأم / ولي الأمر<input name="parent" required maxlength="100"></label><label>البريد الإلكتروني<input name="email" type="email" autocomplete="email" required></label><label>رقم الجوال<input name="phone" type="tel" required maxlength="20"></label><label>كلمة المرور<input name="password" type="password" autocomplete="new-password" required minlength="8"></label><button class="btn secondary full">إنشاء الحساب</button></form></section></div></section>`);
  document.querySelector('#login-form').addEventListener('submit', async e => {
    e.preventDefault(); const fd = new FormData(e.currentTarget);
    const { error } = await supabase.auth.signInWithPassword({ email: fd.get('email'), password: fd.get('password') });
    if (error) note(error.message, true); else await refresh();
  });
  document.querySelector('#signup-form').addEventListener('submit', async e => {
    e.preventDefault(); const fd = new FormData(e.currentTarget);
    const { data, error } = await supabase.auth.signUp({
      email: fd.get('email'), password: fd.get('password'),
      options: { data: { full_name: fd.get('parent'), phone: fd.get('phone') } }
    });
    if (error) return note(error.message, true);
    if (data.session) { await ensureProfile(fd.get('parent'), fd.get('phone')); await refresh(); }
    else note('تم إرسال طلب إنشاء الحساب. تحققي من بريدك لتأكيد الحساب ثم سجّلي الدخول. بعد التأكيد، سجّلي دخولك وأكملي طلب الطفل.');
  });
  document.querySelector('#forgot').addEventListener('click', async () => {
    const email = document.querySelector('#login-form [name=email]').value.trim();
    if (!email) return note('اكتبي بريدك الإلكتروني أولًا.', true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: location.origin });
    note(error ? error.message : 'إذا كان البريد مسجلًا، ستصل تعليمات استعادة كلمة المرور إلى البريد.');
  });
}
async function ensureProfile(fullName, phone='') {
  const user = (await supabase.auth.getUser()).data.user;
  if (!user) return;
  const { data: existing } = await supabase.from('profiles').select('*').eq('id', user.id).maybeSingle();
  if (!existing) {
    const { error } = await supabase.from('profiles').insert({ id: user.id, full_name: fullName || user.user_metadata?.full_name || 'ولي أمر', phone, role: 'parent' });
    if (error) console.error(error);
  }
}
async function refresh() {
  const { data: { session } } = await supabase.auth.getSession();
  state.session = session;
  if (session) {
    const { data, error } = await supabase.from('profiles').select('*').eq('id', session.user.id).maybeSingle();
    state.profile = data;
    if (!data && !error) {
      await ensureProfile(session.user.user_metadata?.full_name || 'ولي أمر', session.user.user_metadata?.phone || '');
      const again = await supabase.from('profiles').select('*').eq('id', session.user.id).maybeSingle();
      state.profile = again.data;
    }
  } else state.profile = null;
  render();
}
function renderDashboard() {
  const role = state.profile?.role;
  const menu = role === 'admin'
    ? [['dashboard','ملخص الإدارة'],['applications','طلبات التسجيل'],['children','الأطفال'],['announcements','الإعلانات']]
    : role === 'teacher'
      ? [['dashboard','الرئيسية'],['children','الأطفال'],['announcements','الإعلانات']]
      : [['dashboard','حساب طفلي'],['apply','تسجيل طفل'],['announcements','الإعلانات']];
  const links = menu.map(([id,label]) => `<button class="nav-item ${state.view===id?'active':''}" data-view="${id}">${label}</button>`).join('');
  shell(`<div class="layout"><aside class="side"><div class="side-title">القائمة الرئيسية</div>${links}</aside><section class="workspace"><div id="view-content"><div class="panel"><p>جارٍ تحميل البيانات…</p></div></div></section></div>`);
  document.querySelectorAll('[data-view]').forEach(b => b.addEventListener('click', async () => { state.view=b.dataset.view; await renderDashboard(); }));
  loadView();
}
async function loadView() {
  const host = document.querySelector('#view-content'); if (!host) return;
  const role = state.profile?.role;
  if (state.view === 'apply' && role === 'parent') {
    host.innerHTML = `<section class="panel"><h2>تسجيل طفل</h2><p class="muted">بعد الإرسال سيظهر الطلب في حسابك بحالة مؤقت إلى أن تراجعه الإدارة.</p><form id="apply-form"><label>اسم الطفل الكامل<input name="child_name" required maxlength="100"></label><div class="form-row"><label>تاريخ الميلاد<input name="birth_date" type="date" required></label><label>القسم<select name="section">${sectionOptions}</select></label></div><button class="btn primary">إرسال طلب التسجيل</button></form></section>`;
    document.querySelector('#apply-form').addEventListener('submit', async e => {
      e.preventDefault(); const fd = new FormData(e.currentTarget);
      const { error } = await supabase.from('child_applications').insert({ parent_id: state.session.user.id, child_name: fd.get('child_name'), birth_date: fd.get('birth_date'), section: fd.get('section'), status: 'pending' });
      if (error) note(error.message, true); else { note('تم إرسال الطلب. حساب الطفل مؤقت حتى موافقة الإدارة.'); state.view='dashboard'; await renderDashboard(); }
    }); return;
  }
  if (state.view === 'applications' && role === 'admin') {
    const { data, error } = await supabase.from('child_applications').select('*, profiles:parent_id(full_name)').order('created_at',{ascending:false});
    if (error) { host.innerHTML = `<section class="panel">تعذر تحميل الطلبات: ${escapeHtml(error.message)}</section>`; return; }
    host.innerHTML = `<section class="panel"><h2>طلبات التسجيل</h2>${data.length ? `<div class="table-wrap"><table><thead><tr><th>الطفل</th><th>القسم</th><th>ولي الأمر</th><th>الحالة</th><th>الإجراء</th></tr></thead><tbody>${data.map(a=>`<tr><td>${escapeHtml(a.child_name)}</td><td>${escapeHtml(a.section)}</td><td>${escapeHtml(a.profiles?.full_name || '')}</td><td><span class="status ${a.status}">${a.status==='pending'?'مؤقت':a.status==='approved'?'رسمي':'مرفوض'}</span></td><td>${a.status==='pending'?`<button class="btn tiny approve" data-id="${a.id}" data-decision="approved">قبول</button> <button class="btn tiny danger approve" data-id="${a.id}" data-decision="rejected">رفض</button>`:'—'}</td></tr>`).join('')}</tbody></table></div>`:'<p class="muted">لا توجد طلبات حتى الآن.</p>'}</section>`;
    host.querySelectorAll('.approve').forEach(b=>b.addEventListener('click',async()=>{
      const {error}=await supabase.rpc('review_child_application',{application_id:b.dataset.id,decision:b.dataset.decision,note:null});
      if(error) note(error.message,true); else { note(b.dataset.decision==='approved'?'تمت الموافقة وتحويل التسجيل إلى رسمي.':'تم رفض الطلب.'); await loadView(); }
    })); return;
  }
  if (state.view === 'children' && ['admin','teacher'].includes(role)) {
    const {data,error}=await supabase.from('children').select('*').order('child_name');
    host.innerHTML = `<section class="panel"><h2>الأطفال المعتمدون</h2>${error?escapeHtml(error.message):data.length?`<div class="table-wrap"><table><thead><tr><th>اسم الطفل</th><th>القسم</th><th>تاريخ الميلاد</th></tr></thead><tbody>${data.map(c=>`<tr><td>${escapeHtml(c.child_name)}</td><td>${escapeHtml(c.section)}</td><td>${escapeHtml(c.birth_date)}</td></tr>`).join('')}</tbody></table></div>`:'<p class="muted">لا يوجد أطفال معتمدون بعد.</p>'}</section>`; return;
  }
  if (state.view === 'announcements') {
    const {data,error}=await supabase.from('announcements').select('*').order('created_at',{ascending:false}).limit(30);
    host.innerHTML=`<section class="panel"><h2>إعلانات المركز</h2>${error?escapeHtml(error.message):data.length?data.map(a=>`<article class="announcement"><h3>${escapeHtml(a.title)}</h3><p>${escapeHtml(a.body)}</p><small>${escapeHtml(a.section || 'عام')}</small></article>`).join(''):'<p class="muted">لا توجد إعلانات.</p>'}</section>`;
    if(role==='admin'||role==='teacher') host.querySelector('.panel').insertAdjacentHTML('beforeend',`<hr><h3>إضافة إعلان</h3><form id="announcement-form"><label>عنوان الإعلان<input name="title" required maxlength="140"></label><label>نص الإعلان<textarea name="body" required maxlength="4000"></textarea></label><label>القسم<select name="section"><option value="">عام</option>${sectionOptions}</select></label><button class="btn primary">نشر الإعلان</button></form>`);
    document.querySelector('#announcement-form')?.addEventListener('submit',async e=>{e.preventDefault();const fd=new FormData(e.currentTarget);const {error}=await supabase.from('announcements').insert({title:fd.get('title'),body:fd.get('body'),section:fd.get('section')||null,created_by:state.session.user.id});if(error)note(error.message,true);else await loadView();});return;
  }
  if (role === 'parent') {
    const {data,error}=await supabase.from('child_applications').select('*').eq('parent_id',state.session.user.id).order('created_at',{ascending:false});
    host.innerHTML=`<section class="panel"><div class="panel-head"><div><h2>حساب طفلي</h2><p class="muted">أهلًا ${escapeHtml(state.profile?.full_name || '')}</p></div><button class="btn primary" id="new-apply">تسجيل طفل</button></div>${error?escapeHtml(error.message):data.length?data.map(a=>`<article class="child-card"><div><h3>${escapeHtml(a.child_name)}</h3><p>${escapeHtml(a.section)} · تاريخ الميلاد ${escapeHtml(a.birth_date)}</p></div><span class="status ${a.status}">${a.status==='pending'?'مؤقت — بانتظار موافقة الإدارة':a.status==='approved'?'رسمي — تمت الموافقة':'لم تتم الموافقة'}</span></article>`).join(''):'<p class="muted">لم تسجلي طفلًا بعد. ابدئي بطلب تسجيل جديد.</p>'}</section>`;
    document.querySelector('#new-apply').addEventListener('click',async()=>{state.view='apply';await renderDashboard();});return;
  }
  if (role === 'admin') {
    const [apps, kids] = await Promise.all([
      supabase.from('child_applications').select('id',{count:'exact',head:true}).eq('status','pending'),
      supabase.from('children').select('id',{count:'exact',head:true})
    ]);
    host.innerHTML=`<section class="hero compact"><span class="eyebrow">لوحة الإدارة</span><h1>مرحبًا بكم في <span>مركز نجوم المضيئة</span></h1><p>تابع طلبات التسجيل واعتمد الأطفال في قسمي التقوى والروضة.</p></section><div class="stats"><article class="stat"><span>طلبات بانتظار الموافقة</span><strong>${apps.count ?? '—'}</strong><button class="text-btn" data-view="applications">مراجعة الطلبات ←</button></article><article class="stat"><span>الأطفال المعتمدون</span><strong>${kids.count ?? '—'}</strong></article></div>`;
    host.querySelector('[data-view="applications"]').addEventListener('click',async()=>{state.view='applications';await renderDashboard();}); return;
  }
  host.innerHTML=`<section class="panel"><h2>مرحبًا بك</h2><p>اختر عنصرًا من القائمة للمتابعة.</p></section>`;
}
function render() {
  if (!configured) return renderSetup();
  if (!state.session) return renderAuth();
  if (!state.profile) {
    shell('<section class="panel"><h2>جاري إعداد حسابك</h2><p>إذا كان حسابك جديدًا، سجّل الدخول مرة أخرى بعد تأكيد البريد الإلكتروني.</p></section>');
    return;
  }
  renderDashboard();
}
if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(console.warn));
if (configured) supabase.auth.onAuthStateChange((_event, session) => { state.session=session; setTimeout(refresh,0); });
refresh().catch(console.error);
