-- منصة مركز نجوم المضيئة
-- نفّذ هذا الملف في Supabase SQL Editor.
-- فعّل RLS ولا تضع service_role key في تطبيق المتصفح.

create extension if not exists pgcrypto;

create type public.app_role as enum ('admin', 'teacher', 'parent');
create type public.application_status as enum ('pending', 'approved', 'rejected');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role public.app_role not null default 'parent',
  phone text,
  created_at timestamptz not null default now()
);

create table public.child_applications (
  id uuid primary key default gen_random_uuid(),
  parent_id uuid not null references auth.users(id) on delete cascade,
  child_name text not null,
  birth_date date not null,
  section text not null check (section in ('التقوى', 'الروضة')),
  status public.application_status not null default 'pending',
  admin_note text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references auth.users(id)
);

create table public.children (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null unique references public.child_applications(id) on delete cascade,
  parent_id uuid not null references auth.users(id) on delete cascade,
  child_name text not null,
  birth_date date not null,
  section text not null check (section in ('التقوى', 'الروضة')),
  created_at timestamptz not null default now()
);

create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  section text check (section in ('التقوى', 'الروضة') or section is null),
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.lessons (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  section text not null check (section in ('التقوى', 'الروضة')),
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

create table public.attendance (
  id uuid primary key default gen_random_uuid(),
  child_id uuid not null references public.children(id) on delete cascade,
  attendance_date date not null default current_date,
  status text not null check (status in ('حاضر', 'غائب', 'متأخر')),
  note text,
  recorded_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  unique (child_id, attendance_date)
);

create or replace function public.current_app_role()
returns public.app_role
language sql
stable
security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.is_staff()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role in ('admin', 'teacher')
  )
$$;

alter table public.profiles enable row level security;
alter table public.child_applications enable row level security;
alter table public.children enable row level security;
alter table public.announcements enable row level security;
alter table public.lessons enable row level security;
alter table public.attendance enable row level security;

create policy "profile read own or staff" on public.profiles
for select to authenticated
using (id = auth.uid() or public.is_staff());

create policy "parent create own profile" on public.profiles
for insert to authenticated
with check (id = auth.uid() and role = 'parent');

create policy "profile update own safe fields" on public.profiles
for update to authenticated
using (id = auth.uid() or public.current_app_role() = 'admin')
with check (
  (id = auth.uid() and role = public.current_app_role())
  or public.current_app_role() = 'admin'
);

create policy "parent read own applications staff read all" on public.child_applications
for select to authenticated
using (parent_id = auth.uid() or public.is_staff());

create policy "parent create own pending application" on public.child_applications
for insert to authenticated
with check (parent_id = auth.uid() and status = 'pending');

create policy "admin update applications" on public.child_applications
for update to authenticated
using (public.current_app_role() = 'admin')
with check (public.current_app_role() = 'admin');

create policy "parent read own children staff read all" on public.children
for select to authenticated
using (parent_id = auth.uid() or public.is_staff());

create policy "staff manage children" on public.children
for all to authenticated
using (public.current_app_role() = 'admin')
with check (public.current_app_role() = 'admin');

create policy "signed in read announcements" on public.announcements
for select to authenticated using (true);

create policy "staff create announcements" on public.announcements
for insert to authenticated
with check (public.is_staff() and created_by = auth.uid());

create policy "admin manage announcements" on public.announcements
for all to authenticated
using (public.current_app_role() = 'admin')
with check (public.current_app_role() = 'admin');

create policy "signed in read lessons" on public.lessons
for select to authenticated using (true);

create policy "staff create lessons" on public.lessons
for insert to authenticated
with check (public.is_staff() and created_by = auth.uid());

create policy "staff read attendance" on public.attendance
for select to authenticated using (public.is_staff() or exists (
  select 1 from public.children c
  where c.id = attendance.child_id and c.parent_id = auth.uid()
));

create policy "staff record attendance" on public.attendance
for insert to authenticated
with check (public.is_staff() and recorded_by = auth.uid());

-- Review applications through this database function, so parent clients cannot self-approve.
create or replace function public.review_child_application(application_id uuid, decision public.application_status, note text default null)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare a public.child_applications%rowtype;
begin
  if public.current_app_role() <> 'admin' then
    raise exception 'Only admins can review applications';
  end if;
  if decision not in ('approved', 'rejected') then
    raise exception 'Decision must be approved or rejected';
  end if;

  select * into a from public.child_applications
  where id = application_id for update;
  if not found then raise exception 'Application not found'; end if;

  update public.child_applications
  set status = decision, admin_note = note, reviewed_at = now(), reviewed_by = auth.uid()
  where id = application_id;

  if decision = 'approved' then
    insert into public.children(application_id, parent_id, child_name, birth_date, section)
    values (a.id, a.parent_id, a.child_name, a.birth_date, a.section)
    on conflict (application_id) do nothing;
  else
    delete from public.children where application_id = a.id;
  end if;
end;
$$;

revoke all on function public.review_child_application(uuid, public.application_status, text) from public;
grant execute on function public.review_child_application(uuid, public.application_status, text) to authenticated;

-- Create first admin profile only after creating the admin user in Supabase Auth.
-- Replace UUID with that user's auth.users id, then run:
-- insert into public.profiles(id, full_name, role) values ('ADMIN-USER-UUID', 'إدارة المركز', 'admin');
